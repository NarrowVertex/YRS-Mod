package com.abnull.yrs.player.data;

import java.util.HashMap;

import com.abnull.yrs.player.slot.skill.PlayerSkillSlot;
import com.abnull.yrs.player.stat.PlayerStat;
import com.abnull.yrs.player.util.PlayerBasicDataManager;
import com.abnull.yrs.proxy.ServerProxy;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public class PlayerDataManager {

	private HashMap<String, PlayerData> data_player_map = new HashMap<String, PlayerData>();
	
	public PlayerDataManager()
	{
		
	}
	
	public void add_player_data(EntityPlayer player)
	{
		String player_name = player.getCommandSenderName();
		PlayerData player_data = new PlayerData(player);
		data_player_map.put(player_name, player_data);
	}
	
	public boolean has_player_data(EntityPlayer player)
	{
		String player_name = player.getCommandSenderName();
		return data_player_map.containsKey(player_name);
	}
	
	public boolean has_player_data_by_name(String player_name)
	{
		return data_player_map.containsKey(player_name);
	}
	
	public PlayerData get_player_data(EntityPlayer player)
	{
		String player_name = player.getCommandSenderName();
		return data_player_map.get(player_name);
	}
	
	public PlayerData get_player_data_by_name(String player_name)
	{
		return data_player_map.get(player_name);
	}
	
	public void remove_player_data(EntityPlayer player)
	{
		data_player_map.remove(player);
	}
	
	public void load_player_data(EntityPlayer player)
	{
		String player_name = player.getCommandSenderName();
		PlayerData player_data = get_player_data_by_name(player_name);
		NBTTagCompound data = player_data.data;
		PlayerStat player_stat = player_data.player_stat;
		PlayerSkillSlot[] player_skill_slot = player_data.player_skill_slot;
		
		NBTTagCompound job_data = ServerProxy.job_data;
		
		float max_health = Float.parseFloat(data.getString("max-hp"));
		float health = Float.parseFloat(data.getString("hp"));
		
		PlayerBasicDataManager.set_max_health(player, max_health);
		PlayerBasicDataManager.set_health(player, health);
		 
		String[] player_job_array = data.getString("jobs").split(";");
		player_data.last_job_data = job_data.getCompoundTag(player_job_array[player_job_array.length - 1]);
		
		NBTTagCompound player_job_data = new NBTTagCompound();
		for(int n = 0; n < player_job_array.length; n++)
		{
			String job_name = player_job_array[n];
			player_job_data.setTag(job_name, job_data.getCompoundTag(job_name));
		}
		data.setTag("job_data", player_job_data);
		
		NBTTagCompound player_skill_level_data = new NBTTagCompound();
		ServerProxy.file_manager.load_player_file(player_skill_level_data, "player_skill_level", player_name, player);
		data.setTag("skill_level_data", player_skill_level_data);
		
		NBTTagCompound player_skill_slot_data = new NBTTagCompound();
		ServerProxy.file_manager.load_player_file(player_skill_slot_data, "player_skill_slot", player_name, player);
		for(int n = 0; n < 6; n++)
		{
			String skill_name = player_skill_slot_data.getString("slot" + (n + 1));
			if(skill_name.equals("n"))
			{
				player_skill_slot[n] = new PlayerSkillSlot();
			}
			else
			{
				player_skill_slot[n] = new PlayerSkillSlot(ServerProxy.skill_data.getCompoundTag(skill_name));
			}
		}
		data.setTag("skill_slot", player_skill_slot_data);
		
		NBTTagCompound player_stat_data = new NBTTagCompound();
		ServerProxy.file_manager.load_player_file(player_stat_data, "player_stat", player_name, player);
		player_stat.read_stat_from_nbt(player_stat_data);
		data.setTag("stat", player_stat_data);
		
		int player_id = player.getEntityId();
		int str_point = player_stat.str;
		int def_point = player_stat.def;
		int acc_point = player_stat.acc;
		int agi_point = player_stat.agi;
		ServerProxy.plugin_communication_manager.get_plugin_data("YRSModHelpPlugin").send_message("PSD", new String[]{ 
				"" + player_id,
				"" + str_point,
				"" + def_point,
				"" + acc_point,
				"" + agi_point });
		
		NBTTagCompound player_potion_data = new NBTTagCompound();
		ServerProxy.file_manager.load_player_file(player_potion_data, "player_potion_tree", player_name, player);
		for(int n = 0; n < 3; n++)
		{
			NBTTagCompound potion_data = player_potion_data.getCompoundTag("" + n);
			boolean is_null = potion_data.getBoolean("is_null");
			
			ItemStack item_stack = new ItemStack(new Item());
			if(!is_null)
			{
    			item_stack.readFromNBT(potion_data.getCompoundTag("data"));
			}
			else
			{
				item_stack = null;
			}
			player_data.player_potion_slot[n] = item_stack;
		}
		data.setTag("potion_tree_data", player_potion_data);
		
		String player_skill_array = "";
		for(int n = 0; n < player_job_array.length; n++)
		{
			String job_name = player_job_array[n];
			player_skill_array += job_data.getCompoundTag(job_name).getString("skill") + ",";
		}
		data.setString("skill_array", player_skill_array);
		ServerProxy.sending_data_manager.send_big_data_to_player(player, "skill_texture", ServerProxy.skill_texture_data, player_skill_array);
	}
	
	public void save_player_data(EntityPlayer player)
	{
		String player_name = player.getCommandSenderName();
		PlayerData player_data = get_player_data_by_name(player_name);
		NBTTagCompound data = player_data.data;
		
		NBTTagCompound player_skill_level_data = data.getCompoundTag("skill_level_data");
		ServerProxy.file_manager.save_player_file(player_skill_level_data, "player_skill_level", player_name, player);
		
		NBTTagCompound player_skill_slot_data = data.getCompoundTag("skill_slot");
		ServerProxy.file_manager.save_player_file(player_skill_slot_data, "player_skill_slot", player_name, player);
		
		NBTTagCompound stat_data = player_data.player_stat.write_stat_to_nbt();
		ServerProxy.file_manager.save_player_file(stat_data, "player_stat", player_name, player);
	
		NBTTagCompound player_potion_data = data.getCompoundTag("potion_tree_data");
		ServerProxy.file_manager.save_player_file(player_potion_data, "player_potion_tree", player_name, player);
	}
}
