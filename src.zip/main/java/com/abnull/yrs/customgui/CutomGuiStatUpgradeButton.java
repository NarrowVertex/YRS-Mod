package com.abnull.yrs.customgui;

import net.minecraft.util.ResourceLocation;

public class CutomGuiStatUpgradeButton extends CustomGuiButtonBase {

	public CutomGuiStatUpgradeButton(int p_i1021_1_, int p_i1021_2_, int p_i1021_3_) {
		super(p_i1021_1_, p_i1021_2_, p_i1021_3_, 0, 108, 11, 7, CustomGuiStat.stat_resource_location);
	}

}
