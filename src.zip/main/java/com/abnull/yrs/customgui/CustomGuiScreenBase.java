package com.abnull.yrs.customgui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public abstract class CustomGuiScreenBase extends GuiScreen {

	public CustomGuiScreenBase()
	{
		this.mc = Minecraft.getMinecraft();
		this.fontRendererObj = this.mc.fontRenderer;
	}
	
}
