package com.abnull.yrs.customgui;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Container;

public abstract class CustomGuiContainerBase extends GuiContainer{

	public CustomGuiContainerBase(Container p_i1072_1_) {
		super(p_i1072_1_);
	}

}
