package com.abnull.yrs.customgui;

public interface ICustomGui {

}
