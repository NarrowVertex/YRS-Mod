package com.abnull.yrs.event.handler.server;

import com.abnull.yrs.player.data.PlayerData;
import com.abnull.yrs.player.util.PlayerBasicDataManager;
import com.abnull.yrs.YRSMod;
import com.abnull.yrs.customgui.handler.CustomGuiHandler;
import com.abnull.yrs.event.server.player.PlayerLevelUpEvent;
import com.abnull.yrs.event.server.plugindata.PluginDataRecvEvent;
import com.abnull.yrs.network.mod.ClientDataMessage;
import com.abnull.yrs.proxy.ServerProxy;
import com.abnull.yrs.util.MathHelper;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerPickupXpEvent;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerLoggedOutEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import cpw.mods.fml.common.gameevent.TickEvent.PlayerTickEvent;

public class IngameEventHandler {

	public IngameEventHandler()
	{
		
	}
	
	@SubscribeEvent
	public void onPlayerLoggedIn(PlayerLoggedInEvent event)
	{
		EntityPlayer player = event.player;
		String player_name = player.getCommandSenderName();
		
		ServerProxy.player_data_manager.add_player_data(player);
		
		NBTTagCompound player_data = ServerProxy.player_data_manager.get_player_data(player).data;
		ServerProxy.file_manager.load_player_file(player_data, "player_data", player_name, player);
		
		ServerProxy.sending_data_manager.send_all_data_to_player(player, player_data);
	}
	
	@SubscribeEvent
	public void onPlayerLoggedOut(PlayerLoggedOutEvent event)
	{
		EntityPlayer player = event.player;
		String player_name = player.getCommandSenderName();
		
		if(ServerProxy.player_data_manager.has_player_data(player))
		{
			NBTTagCompound player_data = ServerProxy.player_data_manager.get_player_data(player).data;
			
			ServerProxy.file_manager.save_player_file(player_data, "player_data", player_name, player);
			ServerProxy.player_data_manager.remove_player_data(player);
		}
		else
		{
			return;
		}
	}
	
	@SubscribeEvent
	public void onPlayerTick(PlayerTickEvent event)
	{
		EntityPlayer player = event.player;
		PlayerData data_player = ServerProxy.player_data_manager.get_player_data(player);
		NBTTagCompound player_data = data_player.data;
		
		if(player.isDead)
			return;
		
		float player_health = player.getHealth();
		int player_mana = Integer.parseInt(player_data.getString("mp"));
		
		long current_time = System.currentTimeMillis();
		
		long pre_hp_regen_time = data_player.pre_hp_regen_time;
		long pre_mp_regen_time = data_player.pre_mp_regen_time;
		
		float hp_regen_speed = Float.parseFloat(player_data.getString("hp-regen-speed"));
		float mp_regen_speed = Float.parseFloat(player_data.getString("mp-regen-speed"));
		
		float hp_regen_amount = Float.parseFloat(player_data.getString("hp-regen-amount"));
		int mp_regen_amount = Integer.parseInt(player_data.getString("mp-regen-amount"));
		
		if((current_time - pre_hp_regen_time) >= hp_regen_speed * 1000)
		{
			PlayerBasicDataManager.set_health(player, player.getHealth() + hp_regen_amount);
			data_player.pre_hp_regen_time = current_time;
			ServerProxy.sending_data_manager.send_each_data_to_player_string(player, player_data, "hp");
		}
		
		if((current_time - pre_mp_regen_time) >= mp_regen_speed * 1000)
		{
			PlayerBasicDataManager.set_mana(player_data, player_mana + mp_regen_amount);
			data_player.pre_mp_regen_time = current_time;
			ServerProxy.sending_data_manager.send_each_data_to_player_string(player, player_data, "mp");
		}
	}
	
	@SubscribeEvent
	public void onPlayerRespawn(PlayerRespawnEvent event)
	{
		EntityPlayer player = event.player;
		PlayerData data_player = ServerProxy.player_data_manager.get_player_data(player);
		NBTTagCompound player_data = data_player.data;
		
		float max_health = Float.parseFloat(player_data.getString("max-hp"));
		
		PlayerBasicDataManager.set_max_health(player, max_health);
		PlayerBasicDataManager.set_health(player, max_health);
		
		int max_mana = Integer.parseInt(player_data.getString("max-mana"));
		
		PlayerBasicDataManager.set_max_mana(player_data, max_mana);
		PlayerBasicDataManager.set_mana(player_data, max_mana);
	}
	
	@SubscribeEvent
	public void onPlayerPickupXp(PlayerPickupXpEvent event)
	{
		EntityPlayer player = event.entityPlayer;
		PlayerData data_player = ServerProxy.player_data_manager.get_player_data(player);
		NBTTagCompound player_data = data_player.data;
		NBTTagCompound job_data = data_player.last_job_data;
		
		int amount = event.orb.getXpValue();
		
		int pre_level = Integer.parseInt(player_data.getString("exp-level"));
		int level = Integer.parseInt(player_data.getString("exp-level"));
		long max_exp = Long.parseLong(player_data.getString("max-exp"));
		long exp = Long.parseLong(player_data.getString("exp"));
		
		exp += amount;
		
		while(exp >= max_exp)
		{
			exp -= max_exp;
			level++;
			
			String exp_equation = job_data.getString("exp-level-up-equation");
			if(exp_equation.contains("'exp'"))
				exp_equation = exp_equation.replaceAll("'exp'", "" + job_data.getString("exp"));
			if(exp_equation.contains("'level'"))
				exp_equation = exp_equation.replaceAll("'level'", "" + level);
			
			max_exp = (long) MathHelper.equation_calculate(exp_equation);
		}
		
		player.experience = 0;
		player.experienceTotal = 0;
		player.experienceLevel = level;
				
		player_data.setString("exp-level", "" + level);
		player_data.setString("max-exp", "" + max_exp);
		player_data.setString("exp", "" + exp);
		ServerProxy.sending_data_manager.send_each_data_to_player_string(player, player_data, "exp-level,max-exp,exp");
		
		if(level > pre_level)
		{
			MinecraftForge.EVENT_BUS.post(new PlayerLevelUpEvent(player, data_player, pre_level, level));
		}
		// Print Xp Amount
		// Result : Just Event Appear When Get XP Orb, Not By XP Command
		// Test With Old Version(Plugin Event)
		// Result : It is same with this event
		// Total Result : This Event
	}
	
	@SubscribeEvent
	public void onPlayerLevelUp(PlayerLevelUpEvent event)
	{
		EntityPlayer player = event.entityPlayer;
		PlayerData data_player = event.player_data;
		NBTTagCompound player_data = data_player.data;
		NBTTagCompound job_data = data_player.last_job_data;
		
		int pre_level = event.pre_level;
		int level = event.level;
		
		double max_hp = Float.parseFloat(job_data.getString("hp"));
		String max_hp_equation = job_data.getString("hp-level-up-equation");
		if(max_hp_equation.contains("'hp'"))
			max_hp_equation = max_hp_equation.replaceAll("'hp'", "" + max_hp);
		if(max_hp_equation.contains("'level'"))
			max_hp_equation = max_hp_equation.replaceAll("'level'", "" + level);
		max_hp = MathHelper.equation_calculate(max_hp_equation);
		player_data.setString("max-hp", "" + max_hp);
		event.entityPlayer.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(max_hp);
		
		int max_mp = Integer.parseInt(job_data.getString("mp"));
		String max_mp_equation = job_data.getString("mp-level-up-equation");
		if(max_mp_equation.contains("'mp'"))
			max_mp_equation = max_mp_equation.replaceAll("'mp'", "" + max_mp);
		if(max_mp_equation.contains("'level'"))
			max_mp_equation = max_mp_equation.replaceAll("'level'", "" + level);
		max_mp = (int) MathHelper.equation_calculate(max_mp_equation);
		player_data.setString("max-mp", "" + max_mp);
		
		ServerProxy.sending_data_manager.send_each_data_to_player_string(player, player_data, "max-hp,max-mp");
	}
}
