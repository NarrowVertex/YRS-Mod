package com.abnull.yrs.file;

import com.abnull.yrs.proxy.ServerProxy;

import net.minecraft.nbt.NBTTagCompound;

public class FileSkill extends FileListFilesBase{

	public FileSkill() {
		super("skill", "Skills");
	}
}
