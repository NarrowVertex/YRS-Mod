package com.abnull.yrs.file;

public class FileSkillTexture extends FileImageBase {

	public FileSkillTexture() {
		super("skill_texture", "SkillTextures");
	}
}
