package com.abnull.yrs.proxy;

import java.io.IOException;
import java.net.ServerSocket;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.MinecraftForge;

import com.abnull.yrs.YRSMod;
import com.abnull.yrs.event.handler.server.ClientActionEventHandler;
import com.abnull.yrs.event.handler.server.IngameEventHandler;
import com.abnull.yrs.event.handler.server.PluginDataEventHandler;
import com.abnull.yrs.file.FileManager;
import com.abnull.yrs.item.handler.RegisterItemHandler;
import com.abnull.yrs.network.mod.ServerSendingDataManager;
import com.abnull.yrs.network.plugin.PluginCommunicationManager;
import com.abnull.yrs.network.plugin.eventhandle.PluginEventHandleManager;
import com.abnull.yrs.player.data.PlayerDataManager;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;

public class ServerProxy implements IProxy {

	public static FileManager file_manager;
	public static PlayerDataManager player_data_manager;
	public static ServerSendingDataManager sending_data_manager;
	public static PluginCommunicationManager plugin_communication_manager;
	public static PluginEventHandleManager plugin_event_handle_manager;
	
	public ClientActionEventHandler client_action_event_handler;
	public IngameEventHandler ingame_event_handler;
	public PluginDataEventHandler plugin_data_event_handler;
	
	public static NBTTagCompound config_data = new NBTTagCompound();
	public static NBTTagCompound stat_config_data = new NBTTagCompound();
	public static NBTTagCompound job_data = new NBTTagCompound();
	public static NBTTagCompound skill_data = new NBTTagCompound();
	public static NBTTagCompound skill_texture_data = new NBTTagCompound();
	
	public static ServerSocket plugin_connection_socket;
	
	public ServerProxy()
	{
		file_manager = new FileManager();
		player_data_manager = new PlayerDataManager();
		sending_data_manager = new ServerSendingDataManager(YRSMod.socket);
		plugin_communication_manager = new PluginCommunicationManager(25566);
		plugin_event_handle_manager = new PluginEventHandleManager();
		
		client_action_event_handler = new ClientActionEventHandler();
		ingame_event_handler = new IngameEventHandler();
		plugin_data_event_handler = new PluginDataEventHandler();
		
		event_handler_registry(client_action_event_handler);
		event_handler_registry(ingame_event_handler);
		event_handler_registry(plugin_data_event_handler);
	}
	
	@Override
	public void pre_init(FMLPreInitializationEvent event)
	{
		file_manager.load_file(config_data, "config");
		file_manager.load_file(stat_config_data, "stat_config");
		file_manager.load_file(skill_data, "skill");
		file_manager.load_file(job_data, "job");
		file_manager.load_file(skill_texture_data, "skill_texture");
	}
	
	@Override
	public void init(FMLInitializationEvent event)
	{
		
	}
	
	@Override
	public void post_init(FMLPostInitializationEvent event)
	{
		
	}
	
	public void event_handler_registry(Object target)
	{
		MinecraftForge.EVENT_BUS.register(target);
		FMLCommonHandler.instance().bus().register(target);
	}
}
