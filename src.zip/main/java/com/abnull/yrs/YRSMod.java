package com.abnull.yrs;

import net.minecraft.entity.player.EntityPlayer;

import com.abnull.yrs.customgui.handler.CustomGuiHandler;
import com.abnull.yrs.item.handler.RegisterItemHandler;
import com.abnull.yrs.network.mod.ClientDataMessage;
// import com.abnull.yrs.network.mod.ServerDataMessage;

import com.abnull.yrs.network.mod.ServerDataMessage;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@Mod(modid = YRSMod.MODID, version = YRSMod.VERSION)
public class YRSMod {

	public static YRSMod instance;
	
	public static final String MODID = "YRS Mod Recreate";
	public static final String VERSION = "1.0";
	
    public static final SimpleNetworkWrapper socket = NetworkRegistry.INSTANCE.newSimpleChannel(YRSMod.MODID);
	
    public static EntityPlayer the_player;
    
    
    @SideOnly(Side.SERVER)
	@Mod.EventHandler
	public void pre_init_server(FMLPreInitializationEvent event)
	{
		new com.abnull.yrs.proxy.ServerProxy().pre_init(event);
	}
	
	@SideOnly(Side.CLIENT)
	@Mod.EventHandler
	public void pre_init_client(FMLPreInitializationEvent event)
	{
		new com.abnull.yrs.proxy.ClientProxy().pre_init(event);
	}
	
	@Mod.EventHandler
	public void init(FMLInitializationEvent event)
	{
		instance = this;
	
		socket.registerMessage(ServerDataMessage.Handler.class, ServerDataMessage.class, 0, Side.SERVER);
		socket.registerMessage(ClientDataMessage.Handler.class, ClientDataMessage.class, 1, Side.CLIENT);
		
		NetworkRegistry.INSTANCE.registerGuiHandler(this, new CustomGuiHandler());
		
		new RegisterItemHandler().register();
	}
}
